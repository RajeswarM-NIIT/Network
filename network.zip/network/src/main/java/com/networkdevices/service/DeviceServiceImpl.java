package com.networkdevices.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.networkdevices.DAO.NetworkDeviceDAOInterface;
import com.networkdevices.model.NetworkDeviceModel;


@Service
@Transactional
public class DeviceServiceImpl implements DeviceService {

	@Autowired
	NetworkDeviceDAOInterface deviceData;
	
	  
	
	public List getAllDevices() {  
		// TODO Auto-generated method stub
		return deviceData.getAllDevices();
		//return null;
	}

	
	public int addDevice(NetworkDeviceModel ndm) {
		// TODO Auto-generated method stub
		//return 0;
		return deviceData.addDevice(ndm);
	}

	
	public NetworkDeviceModel getDevice(String did) {
		// TODO Auto-generated method stub
		//return null;
		return deviceData.getDevice(did);
	}

	
	public String updateDevice(NetworkDeviceModel ndm) {
		// TODO Auto-generated method stub
		//return null;
		return deviceData.editDevice(ndm);
	}

	
	public String deleteDevice(String did) {
		// TODO Auto-generated method stub
		//return null;
		System.out.println("delete..Deviceservice...");
		return deviceData.delDevice(did);
	}

}
