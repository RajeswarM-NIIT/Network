package com.networkdevices.service;

import java.util.List;

import com.networkdevices.model.NetworkDeviceModel;






public interface DeviceService {
	
	public List getAllDevices();
	public int addDevice(NetworkDeviceModel ndm);
	public NetworkDeviceModel getDevice(String did);
	public String updateDevice(NetworkDeviceModel ndm);
	public String deleteDevice(String did); 
  
	
}
 