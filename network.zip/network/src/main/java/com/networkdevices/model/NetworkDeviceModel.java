package com.networkdevices.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="NetworkDeviceModel")
public class NetworkDeviceModel {	    
	@Id
	private String DeviceID;
	private String DeviceName;
	private String DeviceCategory;
	private String DeivceDetails; 
	private int DevicePrice;
	private int DeviceYearOfMade;	
	private String DevicePhotoURL;
	


	public NetworkDeviceModel(){}	   NetworkDeviceModel(String Did, String Dname, String Dcat, String Ddet, int Dprice, int Dyom, String url)
	{
		this.DeviceID=Did;
		this.DeviceName=Dname;
		this.DeviceCategory=Dcat;
		this.DeivceDetails=Ddet;
		this.DevicePrice=Dprice;
		this.DeviceYearOfMade=Dyom;	
		this.DevicePhotoURL=url;
	}
	
	public String getDeviceID() {
		return DeviceID;
	}
	public void setDeviceID(String deviceID) {
		DeviceID = deviceID;
	}
	public String getDeviceName() {
		return DeviceName;
	}
	public void setDeviceName(String deviceName) {
		DeviceName = deviceName;
	}
	public String getDeviceCategory() {
		return DeviceCategory;
	}
	public void setDeviceCategory(String deviceCategory) {
		DeviceCategory = deviceCategory;
	}
	public String getDeivceDetails() {
		return DeivceDetails;
	}
	public void setDeivceDetails(String deivceDetails) {
		DeivceDetails = deivceDetails;
	}
	public int getDevicePrice() {
		return DevicePrice;
	}
	public void setDevicePrice(int devicePrice) {
		DevicePrice = devicePrice;
	}
	public int getDeviceYearOfMade() {
		return DeviceYearOfMade;
	}
	public void setDeviceYearOfMade(int deviceYearOfMade) {
		DeviceYearOfMade = deviceYearOfMade;
	}	
	public String getDevicePhotoURL() {
		return DevicePhotoURL;
	}
	public void setDevicePhotoURL(String devicePhotoURL) {
		DevicePhotoURL = devicePhotoURL;
	}	
}
