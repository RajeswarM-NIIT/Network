package com.networkdevices.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="UserModel")
public class UserModel {
	@Id
	private String UserID;
	private String Password;
	private String UserRoll;
	private String UserStatus;
	
	public UserModel(){}
	public UserModel(String userID, String password, String userRoll, String userStatus) {
		super();
		UserID = userID;
		Password = password;
		UserRoll = userRoll;
		UserStatus = userStatus;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getUserRoll() {
		return UserRoll;
	}
	public void setUserRoll(String userRoll) {
		UserRoll = userRoll;
	}
	public String getUserStatus() {
		return UserStatus;
	}
	public void setUserStatus(String userStatus) {
		UserStatus = userStatus;
	}	
}
