package com.networkdevices.DAO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.networkdevices.model.NetworkDeviceModel;


public class NetworkDeviceDAO implements NetworkDeviceDAOInterface{

	List <NetworkDeviceModel> lst = new ArrayList<NetworkDeviceModel>();
	
	NetworkDeviceModel deviceData;
	
	
	@Autowired
	private SessionFactory sessionFactory;   
	
	public NetworkDeviceDAO(){}
	
	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory=sessionFactory;
	}
	
	public Session getCurrentSession(){
		return sessionFactory.getCurrentSession();
	}
	
	
	
	public int addDevice(NetworkDeviceModel ndm) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		System.out.println("After current");
		session.save(ndm);
		tx.commit();
		Serializable id = session.getIdentifier(ndm);
		session.close();
		return (Integer)id;				
		//return 0;
	}	
	
	
	public List<NetworkDeviceModel> getAllDevices() {
		// TODO Auto-generated method stub
		List<NetworkDeviceModel> lst;
		System.out.println("getAllDevices()");
		Session ses = sessionFactory.openSession();
		System.out.println("getAllDevices()session " + ses.isOpen());
		Query qry = ses.createQuery("from NetworkDeviceModel");
		lst = qry.list();
		System.out.println(lst);
		return lst;			
	}

	
	public NetworkDeviceModel getDevice(String did) {  
		// TODO Auto-generated method stub
		Session ses=sessionFactory.openSession();
		deviceData = (NetworkDeviceModel)ses.get(NetworkDeviceModel.class,did);
		return deviceData;		
	}

	
	public String editDevice(NetworkDeviceModel ndm) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		System.out.println("editDevice()");
		session.saveOrUpdate(ndm);
		tx.commit();
		Serializable id = session.getIdentifier(ndm);
		session.close();
		return (String)id;		
	}

	
	public String delDevice(String did) {
		// TODO Auto-generated method stub
		System.out.println("deldevice()in DAO is running....");
		Session session = sessionFactory.openSession();
		Transaction tx = (Transaction)session.beginTransaction();
		NetworkDeviceModel ndm = (NetworkDeviceModel)session.load(NetworkDeviceModel.class, did);
		session.delete(ndm);
		Serializable ids = session.getIdentifier(ndm);
		session.close();
		return (String)ids;	
	}
	

	
	
	
	
	
	
	
	/*
	List<NetworkDeviceModel> devices;	
	public List<NetworkDeviceModel> getDevice(String name){
		
		devices = new ArrayList<NetworkDeviceModel>();
		NetworkDeviceModel dm1 = null;

		if("rtr1".equals(name))
			dm1 = new NetworkDeviceModel("R1600","CISCO 1623","Access Layer","RC1 Processor, 16MB RAM, 128KB NV-RAM, 2F",17000,2009,"resources/images/rtr1.JPG");    
		if("sw1".equals(name))
			dm1 = new NetworkDeviceModel("S2600","CISCO 2950","Access Layer","RC2 Processor, 256MB RAM, 256KB NV-RAM, 24F",65000,2008,"resources/images/sw1.JPG");   
		if("wifi1".equals(name))
			dm1 = new NetworkDeviceModel("W1500","CISCO 1598","Access Layer","RC1B Processor, WAP+Wifi 4MB RAM, ACL,WEB UI",40000,2011,"resources/images/wifi1.JPG");
		if("rtr2".equals(name))
			dm1 =new NetworkDeviceModel("R3600","CISCO 3668","Distribution Layer","RC3 Processor, 64MB RAM, 256KB NV-RAM, 2F, 2S, 2Fi",120000,2012,"resources/images/rtr2.JPG");
		if("sw2".equals(name))
			dm1 = new NetworkDeviceModel("S6700","CISCO 6785","Core Layer","RC5 Processor, 128MB RAM, 512KB NV-RAM, 48F, 2G",95000,2013,"resources/images/sw2.JPG");
		if("wifi2".equals(name))
			dm1 = new NetworkDeviceModel("W2000","CISCO 2845","Home Business","RC2 Processor, WAP+Wifi 8MB RAM, WEB UI",45000,2015,"resources/images/wifi2.JPG");
		devices.add(dm1);
		return devices; 
	}
	
	public List<NetworkDeviceModel> getAllDevices(){		
		devices = new ArrayList<NetworkDeviceModel>();	
		NetworkDeviceModel nd1 = new NetworkDeviceModel("R1600","CISCO 1623","Access Layer","RC1 Processor, 16MB RAM, 128KB NV-RAM, 2F",17000,2009,"resources/images/rtr1.JPG");    
		NetworkDeviceModel nd2 = new NetworkDeviceModel("S2600","CISCO 2950","Access Layer","RC2 Processor, 256MB RAM, 256KB NV-RAM, 24F",65000,2008,"resources/images/sw1.JPG");   
		NetworkDeviceModel nd3 = new NetworkDeviceModel("W1500","CISCO 1598","Access Layer","RC1B Processor, WAP+Wifi 4MB RAM, ACL,WEB UI",40000,2011,"resources/images/wifi1.JPG");
		NetworkDeviceModel nd4 = new NetworkDeviceModel("R3600","CISCO 3668","Distribution Layer","RC3 Processor, 64MB RAM, 256KB NV-RAM, 2F, 2S, 2Fi",120000,2012,"resources/images/rtr2.JPG"); 
		NetworkDeviceModel nd5 = new NetworkDeviceModel("S6700","CISCO 6785","Core Layer","RC5 Processor, 128MB RAM, 512KB NV-RAM, 48F, 2G",95000,2013,"resources/images/sw2.JPG");
		NetworkDeviceModel nd6 = new NetworkDeviceModel("W2000","CISCO 2845","Home Business","RC2 Processor, WAP+Wifi 8MB RAM, WEB UI",45000,2015,"resources/images/wifi2.JPG");
	//System.out.println("first record started");
		devices.add(nd1);
		//System.out.println("second record started");
		devices.add(nd2);
		//System.out.println("third record started");
		devices.add(nd3);
		devices.add(nd4);
		devices.add(nd5);
		devices.add(nd6);		
		return devices;		
	}
	*/
	
}
