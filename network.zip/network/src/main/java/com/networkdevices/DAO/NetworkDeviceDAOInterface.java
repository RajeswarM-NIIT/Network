package com.networkdevices.DAO;

import com.networkdevices.model.NetworkDeviceModel;
import java.util.List;

public interface NetworkDeviceDAOInterface { 
	public List<NetworkDeviceModel> getAllDevices();
	public NetworkDeviceModel getDevice(String did);
	public String editDevice(NetworkDeviceModel ndm);
	public String delDevice(String did);
	public int addDevice(NetworkDeviceModel ndm); 
} 
